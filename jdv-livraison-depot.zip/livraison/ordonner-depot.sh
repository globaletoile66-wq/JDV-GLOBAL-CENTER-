#!/usr/bin/env bash
# Range le dépôt JDV Global Center et y applique la fusion Rocket + modules v2.
# À lancer DEPUIS LA RACINE d'un clone propre du dépôt :   bash ../livraison/ordonner-depot.sh
# Aucune donnée n'est supprimée : tout passe par git (réversible), sur une nouvelle branche.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FUSION="$HERE/fusion"; ROCKET="$HERE/rocket-base"
BRANCH="integration/rocket-fusion-2026-10-15"
REVIEW="_a-revoir"; MERGE="_fusion-a-fusionner"
[ -d .git ] || { echo "Lancez le script à la racine du clone."; exit 1; }
[ -z "$(git status --porcelain)" ] || { echo "Dépôt non propre : commitez ou stashez d'abord."; exit 1; }
git checkout -b "$BRANCH"
moved=0; dup=0; conflicts=0; added=0; updated=0; skipped=0; mergeconf=0

# Place un fichier SRC vers DEST (chemins relatifs au dépôt). Règle : jamais d'écrasement silencieux.
place() {
  local src="$1" dest="$2"
  if [ ! -e "$dest" ]; then mkdir -p "$(dirname "$dest")"; git mv "$src" "$dest"; moved=$((moved+1))
  elif cmp -s "$src" "$dest"; then git rm -q -f "$src"; dup=$((dup+1))
  else mkdir -p "$(dirname "$REVIEW/$dest")"; git mv "$src" "$REVIEW/$dest"; conflicts=$((conflicts+1)); fi
}
place_dir() {  # place_dir DOSSIER_RACINE DOSSIER_CIBLE
  [ -d "$1" ] || return 0
  while IFS= read -r f; do place "$f" "$2/${f#"$1"/}"; done < <(git ls-files "$1")
}

echo "== 1/4 Fichiers posés à plat à la racine -> emplacement Next.js"
for pair in "AppIcon.tsx:src/components/ui" "AppImage.tsx:src/components/ui" "AppLogo.tsx:src/components/ui" \
            "AuthContext.tsx:src/contexts" "JDVContext.tsx:src/contexts" "LoginPageContent.tsx:src/app/auth/login" \
            "client.ts:src/lib/supabase" "server.ts:src/lib/supabase" "layout.tsx:src/app" "not-found.tsx:src/app" \
            "tailwind.css:src/styles" "index.css:src/styles"; do
  f="${pair%%:*}"; d="${pair##*:}"; [ -f "$f" ] && place "$f" "$d/$f"
done
[ -f middleware.ts ] && place middleware.ts src/middleware.ts
[ -f route.ts ] && place route.ts src/app/auth/callback/route.ts
# page.tsx racine (117 octets) : destination inconnue -> à examiner
[ -f page.tsx ] && { mkdir -p "$REVIEW"; git mv page.tsx "$REVIEW/page.tsx"; conflicts=$((conflicts+1)); }

echo "== 2/4 Dossiers de pages posés à la racine -> src/app"
for d in appointments clients expenses invoices products reports sales team create; do place_dir "$d" "src/app/business/$d"; done
for d in coming-soon help maintenance notifications onboarding organizations profile services settings super-admin \
         user-dashboard landing-home-page sign-up-login-screen dashboard marketplace pay immo crm; do place_dir "$d" "src/app/$d"; done
for d in components contexts lib; do place_dir "$d" "src/$d"; done

# supprime les dossiers racine devenus vides (non suivis par git)
for d in appointments clients expenses invoices products reports sales team create coming-soon help maintenance notifications onboarding organizations profile services settings super-admin user-dashboard landing-home-page sign-up-login-screen dashboard marketplace pay immo crm components contexts lib; do [ -d "$d" ] && find "$d" -depth -type d -empty -delete 2>/dev/null || true; done

echo "== 3/4 Archives, SQL et schémas historiques"
mkdir -p archives database/reference/racine-historique
for z in jdvglobalcenter.zip jdvglobalcenter-crm.zip; do [ -f "$z" ] && git mv "$z" "archives/$z"; done
for s in 2026*.sql; do [ -f "$s" ] && git mv "$s" "database/reference/racine-historique/$s"; done
[ -f shema ] && git mv shema database/reference/racine-historique/schema-historique.sql
git add -A; git commit -q -m "Range le dépôt : fichiers à plat vers src/, archives et SQL historiques classés" || true

echo "== 4/4 Fusion Rocket + modules v2 (comparaison à trois : dépôt / base Rocket / fusion)"
while IFS= read -r rel; do
  fus="$FUSION/$rel"; roc="$ROCKET/$rel"
  if [ ! -e "$rel" ]; then mkdir -p "$(dirname "$rel")"; cp "$fus" "$rel"; added=$((added+1))
  elif cmp -s "$fus" "$rel"; then skipped=$((skipped+1))
  elif [ -f "$roc" ] && cmp -s "$roc" "$rel"; then cp "$fus" "$rel"; updated=$((updated+1))
  else mkdir -p "$(dirname "$MERGE/$rel")"; cp "$fus" "$MERGE/$rel"; mergeconf=$((mergeconf+1)); fi
done < <(cd "$FUSION" && find . -type f ! -name '.DS_Store' | sed 's#^\./##' | sort)
git add -A; git commit -q -m "Fusionne la base Rocket et les modules v2 (auth, abonnements, KYC, PAY, dashboard, accueil)"

cat <<R

Terminé sur la branche $BRANCH (rien n'est poussé).
  Fichiers à plat déplacés           : $moved
  Doublons identiques supprimés      : $dup
  Cas à examiner (dossier $REVIEW)   : $conflicts
  Fusion : ajoutés $added | mis à jour $updated | identiques $skipped
  Fusion : conflits à fusionner à la main (dossier $MERGE) : $mergeconf

Étapes suivantes :
  1. Lire $REVIEW/ et $MERGE/, reprendre à la main ce qui doit l'être, puis les supprimer.
  2. npm install && npm run type-check && npm run build
  3. git push -u origin $BRANCH   (puis ouvrir une pull request, ne pas pousser sur la branche par défaut)
R
