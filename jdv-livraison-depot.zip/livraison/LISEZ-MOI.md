# Livraison : rangement du dépôt et fusion Rocket + modules v2

Contenu : `fusion/` (arbre complet à jour), `rocket-base/` (base Rocket d'origine, sert de référence pour la comparaison),
`ordonner-depot.sh` (le script).

## Utilisation
```bash
git clone https://github.com/globaletoile66-wq/JDV-GLOBAL-CENTER-.git
cd JDV-GLOBAL-CENTER-            # branche par défaut : supabase-sync-2026-09-24
bash ../livraison/ordonner-depot.sh
```
Le script crée la branche `integration/rocket-fusion-2026-10-15`, fait 2 commits locaux, ne pousse rien et ne supprime
rien définitivement (tout est dans l'historique git).

## Règles appliquées
- Fichiers posés à plat à la racine : déplacés vers `src/...` ; doublon identique supprimé ; si le fichier existe déjà
  dans `src/` avec un contenu différent, la version racine va dans `_a-revoir/` (rien n'est écrasé).
- Zips racine -> `archives/` ; SQL racine et `shema` -> `database/reference/racine-historique/`.
- Fusion : fichier absent -> ajouté ; fichier identique à la base Rocket -> mis à jour ; fichier modifié dans le dépôt
  -> la version fusionnée va dans `_fusion-a-fusionner/` pour fusion à la main.
- Les pages déjà présentes dans le dépôt pour les autres branches (academy, immo, travel, tontine...) ne sont pas touchées.

## À vérifier après le script
`npm install && npm run type-check && npm run build`, puis lire `_a-revoir/` et `_fusion-a-fusionner/`.
Les branches `fix/*` et `feat/*` du 12/10 ne sont pas fusionnées dans la branche par défaut : à revoir une par une.
