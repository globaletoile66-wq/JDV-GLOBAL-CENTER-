#!/usr/bin/env bash
# Résout les conflits de fusion connus (décisions prises après lecture des deux versions).
# Appelé par ordonner-depot.sh depuis la racine du dépôt. Arguments : $1=fusion/  $2=_fusion-a-fusionner
set -uo pipefail
FUSION="$1"; MERGE="$2"; DOC="docs/RESOLUTIONS-FUSION.md"; mkdir -p docs
ok=(); ko=()
done_() { ok+=("$1"); }; fail_() { ko+=("$1"); }
drop() { [ -e "$MERGE/$1" ] && rm -f "$MERGE/$1"; }

# 1) middleware : on GARDE la version du dépôt (portail concepteur, contrôle super-admin côté serveur, /business, /terrain)
#    et on y ajoute seulement : routes /abonnements et /espace protégées + garde MFA.
if [ -f src/middleware.ts ] && python3 - <<'PY'
import sys
p='src/middleware.ts'; s=open(p,encoding='utf-8').read()
if 'mfaRedirect' in s: sys.exit(0)
steps=[
 ("import { NextResponse, type NextRequest } from 'next/server';",
  "import { NextResponse, type NextRequest } from 'next/server';\nimport { mfaRedirect } from '@/lib/auth/middlewareGuards';"),
 ("'/business', '/terrain'];","'/business', '/terrain', '/abonnements', '/espace'];"),
 ("  // Hidden concepteur portal",
  "  if (user && isProtected) {\n    const mfa = await mfaRedirect(supabase, request);\n    if (mfa) return mfa;\n  }\n\n  // Hidden concepteur portal"),
]
for a,b in steps:
    if a not in s: sys.exit(1)
    s=s.replace(a,b,1)
open(p,'w',encoding='utf-8').write(s)
PY
then drop src/middleware.ts; done_ "middleware.ts : version du dépôt conservée + garde MFA + routes /abonnements et /espace protégées"
else fail_ "middleware.ts : points d'insertion introuvables -> à faire à la main (voir $MERGE/src/middleware.ts)"; fi

# 2) mot de passe oublié : le lien passe par /auth/callback (échange du code) puis /auth/reset-password
f=src/app/auth/forgot-password/page.tsx
if [ -f "$f" ] && grep -q "window.location.origin+'/auth/reset-password'" "$f"; then
  sed -i "s#window.location.origin+'/auth/reset-password'#window.location.origin+'/auth/callback?next=/auth/reset-password'#" "$f"
  drop src/app/auth/forgot-password/page.tsx; done_ "forgot-password : lien de réinitialisation via /auth/callback (page du dépôt conservée)"
else fail_ "forgot-password : chaîne attendue introuvable"; fi

# 3) inscription : si aucune session (e-mail à confirmer) -> page de vérification d'e-mail
f=src/app/auth/register/page.tsx
if [ -f "$f" ] && grep -q "'/auth/login?registered=1'" "$f"; then
  sed -i "s#'/auth/login?registered=1'#\`/auth/verify-email?email=\${encodeURIComponent(email)}\`#" "$f"
  drop src/app/auth/register/page.tsx; done_ "register : redirection vers /auth/verify-email si confirmation d'e-mail requise (page du dépôt conservée)"
else fail_ "register : chaîne attendue introuvable"; fi

# 4) AuthContext : on garde la version du dépôt (correctif de course d'authentification)
[ -e "$MERGE/src/contexts/AuthContext.tsx" ] && { drop src/contexts/AuthContext.tsx; done_ "AuthContext : version du dépôt conservée (anti-course d'authentification)"; }

# 5) PAY : la page du dépôt est un simple listing JSON de portefeuilles ; la v2 (portefeuilles, actions, opérations) la remplace
if [ -f "$FUSION/src/app/pay/page.tsx" ] && { [ -f src/hooks/usePayWallets.ts ] || [ -f src/hooks/usePayWallets.tsx ]; }; then
  cp "$FUSION/src/app/pay/page.tsx" src/app/pay/page.tsx; drop src/app/pay/page.tsx
  done_ "pay/page.tsx : remplacée par l'accueil JDV PAY v2 (version du dépôt = listing brut de portefeuilles)"
else fail_ "pay/page.tsx : dépendances v2 absentes"; fi

# 6) /dashboard du dépôt = routeur (super-admin / prospecteur / business) : conservé. Le tableau de bord v2 est ajouté à part.
if [ -f "$FUSION/src/app/dashboard/page.tsx" ]; then
  mkdir -p src/app/espace; cp "$FUSION/src/app/dashboard/page.tsx" src/app/espace/page.tsx; drop src/app/dashboard/page.tsx
  done_ "dashboard : /dashboard (routeur du dépôt) conservé ; tableau de bord v2 publié sur /espace"
fi

# 7) accueil : la page d'accueil du dépôt reste sur / ; la v2 est publiée sur /accueil-v2
if [ -f "$FUSION/src/app/page.tsx" ]; then
  mkdir -p src/app/accueil-v2; sed "s#from '\.\./components/#from '@/components/#g" "$FUSION/src/app/page.tsx" > src/app/accueil-v2/page.tsx
  drop src/app/page.tsx; done_ "accueil : page du dépôt conservée sur / ; accueil v2 publié sur /accueil-v2 (à comparer)"
fi

# 8) configuration : on garde celle du dépôt, sauf règle .gitignore pour les secrets
if [ -f .gitignore ] && ! grep -q '^\.env' .gitignore; then printf '\n# secrets\n.env\n.env.*\n!.env.example\n' >> .gitignore; done_ ".gitignore : règles .env ajoutées"; fi
for c in .gitignore package.json netlify.toml .env.example; do drop "$c"; done
done_ "package.json, netlify.toml, .env.example : versions du dépôt conservées"

{
  echo "# Résolutions de la fusion Rocket + modules v2"; echo
  echo "## Appliquées automatiquement"; for x in "${ok[@]}"; do echo "- $x"; done
  echo; echo "## À faire à la main"; if [ ${#ko[@]} -eq 0 ]; then echo "- (aucune)"; else for x in "${ko[@]}"; do echo "- $x"; done; fi
  echo; echo "Les fichiers restants dans \`_a-revoir/\` (versions posées à plat à la racine, différentes de celles de \`src/\`) sont à examiner avant suppression."
} > "$DOC"
echo "-- résolutions appliquées : ${#ok[@]} ; à la main : ${#ko[@]}"; for x in "${ko[@]}"; do echo "   ! $x"; done
find "$MERGE" -depth -type d -empty -delete 2>/dev/null || true
