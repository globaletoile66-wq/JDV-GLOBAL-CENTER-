'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useForm } from 'react-hook-form';
import { Loader2, AlertCircle, ArrowLeft, Mail } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import AppLogo from '@/components/ui/AppLogo';

interface ForgotFormData {
  email: string;
}

export default function ForgotPasswordPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sent, setSent] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm<ForgotFormData>();

  const onSubmit = async (data: ForgotFormData) => {
    setIsLoading(true);
    setError(null);
    try {
      const supabase = createClient();
      const { error: err } = await supabase.auth.resetPasswordForEmail(data.email, {
        redirectTo: `${process.env.NEXT_PUBLIC_SITE_URL}/auth/reset-password`,
      });
      if (err) throw err;
      setSent(true);
    } catch (err: any) {
      setError(err?.message || 'Une erreur est survenue. Veuillez réessayer.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-6 py-12">
      <div className="max-w-md w-full">
        <div className="flex items-center gap-3 mb-10">
          <AppLogo size={36} />
          <div className="flex flex-col leading-none">
            <span className="font-extrabold text-base text-foreground">JDV</span>
            <span className="text-xs text-muted-foreground tracking-widest uppercase">Global Center</span>
          </div>
        </div>

        <Link href="/auth/login" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-8">
          <ArrowLeft size={15} />
          Retour à la connexion
        </Link>

        {sent ? (
          <div className="text-center animate-scale-in">
            <div className="w-16 h-16 rounded-full bg-success/15 border border-success/30 flex items-center justify-center mx-auto mb-6">
              <Mail size={32} className="text-success" />
            </div>
            <h2 className="text-2xl font-bold text-foreground mb-3">Email envoyé !</h2>
            <p className="text-muted-foreground mb-6">
              Si cette adresse email est associée à un compte JDV, vous recevrez un lien de récupération dans quelques minutes.
            </p>
            <p className="text-sm text-muted-foreground">
              Vérifiez également votre dossier spam.
            </p>
            <Link href="/auth/login" className="btn-primary mt-8 inline-flex">
              Retour à la connexion
            </Link>
          </div>
        ) : (
          <>
            <div className="mb-8">
              <h2 className="text-3xl font-extrabold text-foreground mb-2">Mot de passe oublié</h2>
              <p className="text-muted-foreground">
                Entrez votre adresse email et nous vous enverrons un lien pour réinitialiser votre mot de passe.
              </p>
            </div>

            {error && (
              <div className="flex items-start gap-3 px-4 py-3 rounded-xl bg-danger/10 border border-danger/25 mb-6">
                <AlertCircle size={16} className="text-danger flex-shrink-0 mt-0.5" />
                <p className="text-sm text-danger font-medium">{error}</p>
              </div>
            )}

            <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-5" noValidate>
              <div className="flex flex-col gap-1.5">
                <label htmlFor="forgot-email" className="text-sm font-semibold text-foreground">
                  Adresse email <span className="text-danger">*</span>
                </label>
                <input
                  id="forgot-email"
                  type="email"
                  autoComplete="email"
                  placeholder="votre@email.com"
                  className="jdv-input"
                  {...register('email', {
                    required: 'L\'adresse email est requise',
                    pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: 'Format d\'email invalide' },
                  })}
                />
                {errors.email && <p className="text-xs text-danger font-medium">{errors.email.message}</p>}
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="btn-primary w-full justify-center py-3.5 text-base disabled:opacity-60 disabled:cursor-not-allowed disabled:transform-none"
              >
                {isLoading ? <Loader2 size={18} className="animate-spin" /> : 'Envoyer le lien de récupération'}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
