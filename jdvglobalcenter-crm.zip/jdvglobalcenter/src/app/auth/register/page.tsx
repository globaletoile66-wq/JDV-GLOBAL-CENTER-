'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { Eye, EyeOff, Loader2, AlertCircle, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import AppLogo from '@/components/ui/AppLogo';

interface RegisterFormData {
  first_name: string;
  last_name: string;
  email: string;
  password: string;
  confirm_password: string;
  terms: boolean;
  privacy: boolean;
}

function getPasswordStrength(password: string): { score: number; label: string; color: string } {
  if (!password) return { score: 0, label: '', color: '' };
  let score = 0;
  if (password.length >= 8) score++;
  if (password.length >= 12) score++;
  if (/[A-Z]/.test(password)) score++;
  if (/[0-9]/.test(password)) score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;
  if (score <= 1) return { score, label: 'Très faible', color: 'bg-danger' };
  if (score === 2) return { score, label: 'Faible', color: 'bg-warning' };
  if (score === 3) return { score, label: 'Moyen', color: 'bg-yellow-400' };
  if (score === 4) return { score, label: 'Fort', color: 'bg-success' };
  return { score, label: 'Très fort', color: 'bg-success' };
}

export default function RegisterPage() {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const { signUp } = useAuth();
  const router = useRouter();

  const { register, handleSubmit, watch, formState: { errors } } = useForm<RegisterFormData>();
  const password = watch('password', '');
  const strength = getPasswordStrength(password);

  const onSubmit = async (data: RegisterFormData) => {
    setIsLoading(true);
    setAuthError(null);
    try {
      await signUp(data.email, data.password, {
        first_name: data.first_name,
        last_name: data.last_name,
        full_name: `${data.first_name} ${data.last_name}`,
      });
      setSuccess(true);
      toast.success(`Compte créé ! Bienvenue ${data.first_name} sur JDV GLOBAL CENTER`);
      setTimeout(() => router.push('/onboarding'), 1500);
    } catch (err: any) {
      const msg = err?.message || 'Erreur lors de la création du compte';
      if (msg.includes('already registered') || msg.includes('already been registered')) {
        setAuthError('Cette adresse email est déjà utilisée. Connectez-vous ou utilisez une autre adresse.');
      } else if (msg.includes('Password should be')) {
        setAuthError('Le mot de passe doit contenir au moins 6 caractères.');
      } else {
        setAuthError(msg);
      }
    } finally {
      setIsLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center px-6">
        <div className="max-w-md w-full text-center animate-scale-in">
          <div className="w-20 h-20 rounded-full bg-success/15 border border-success/30 flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 size={40} className="text-success" />
          </div>
          <h2 className="text-2xl font-bold text-foreground mb-3">Compte créé avec succès !</h2>
          <p className="text-muted-foreground mb-2">Redirection vers la configuration de votre profil...</p>
          <div className="flex justify-center mt-4">
            <Loader2 size={20} className="animate-spin text-accent" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex">
      {/* Brand panel */}
      <div className="hidden lg:flex lg:w-2/5 bg-jdv-gradient relative overflow-hidden flex-col justify-between p-12">
        <div className="absolute inset-0 bg-jdv-hero" />
        <div className="absolute top-1/3 left-1/4 w-96 h-96 blob-primary opacity-60" />
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 blob-accent opacity-40" />
        <div className="relative z-10">
          <Link href="/" className="flex items-center gap-3">
            <AppLogo size={44} />
            <div className="flex flex-col leading-none">
              <span className="font-extrabold text-xl text-white">JDV</span>
              <span className="text-xs text-white/60 tracking-widest uppercase">Global Center</span>
            </div>
          </Link>
        </div>
        <div className="relative z-10">
          <h1 className="text-3xl font-extrabold text-white mb-4 leading-tight">
            Rejoignez l'écosystème<br />
            <span className="text-accent">JDV GLOBAL CENTER</span>
          </h1>
          <div className="flex flex-col gap-3 mt-6">
            {['Un compte, tous les services JDV', 'Disponible dans 15+ pays', 'Sécurisé et confidentiel', 'Gratuit pour commencer'].map((item, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="w-5 h-5 rounded-full bg-accent/20 border border-accent/40 flex items-center justify-center flex-shrink-0">
                  <CheckCircle2 size={12} className="text-accent" />
                </div>
                <span className="text-white/80 text-sm">{item}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="relative z-10 text-white/40 text-xs">
          © {new Date().getFullYear()} JDV GLOBAL CENTER. Tous droits réservés.
        </div>
      </div>

      {/* Form panel */}
      <div className="flex-1 flex flex-col justify-center px-6 py-12 lg:px-12 xl:px-16 overflow-y-auto">
        <div className="max-w-lg w-full mx-auto">
          <div className="lg:hidden flex items-center gap-3 mb-8">
            <AppLogo size={36} />
            <div className="flex flex-col leading-none">
              <span className="font-extrabold text-base text-foreground">JDV</span>
              <span className="text-xs text-muted-foreground tracking-widest uppercase">Global Center</span>
            </div>
          </div>

          <Link href="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-8">
            <ArrowLeft size={15} />
            Retour à l'accueil
          </Link>

          <div className="mb-8">
            <h2 className="text-3xl font-extrabold text-foreground mb-2">Créer mon compte</h2>
            <p className="text-muted-foreground">Rejoignez l'écosystème JDV GLOBAL CENTER</p>
          </div>

          {authError && (
            <div className="flex items-start gap-3 px-4 py-3 rounded-xl bg-danger/10 border border-danger/25 mb-6 animate-slide-up">
              <AlertCircle size={16} className="text-danger flex-shrink-0 mt-0.5" />
              <p className="text-sm text-danger font-medium leading-snug">{authError}</p>
            </div>
          )}

          <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-4" noValidate>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-1.5">
                <label htmlFor="first_name" className="text-sm font-semibold text-foreground">
                  Prénom <span className="text-danger">*</span>
                </label>
                <input
                  id="first_name"
                  type="text"
                  autoComplete="given-name"
                  placeholder="Prénom"
                  className="jdv-input"
                  {...register('first_name', { required: 'Prénom requis', minLength: { value: 2, message: '2 caractères min.' } })}
                />
                {errors.first_name && <p className="text-xs text-danger font-medium">{errors.first_name.message}</p>}
              </div>
              <div className="flex flex-col gap-1.5">
                <label htmlFor="last_name" className="text-sm font-semibold text-foreground">
                  Nom <span className="text-danger">*</span>
                </label>
                <input
                  id="last_name"
                  type="text"
                  autoComplete="family-name"
                  placeholder="Nom de famille"
                  className="jdv-input"
                  {...register('last_name', { required: 'Nom requis', minLength: { value: 2, message: '2 caractères min.' } })}
                />
                {errors.last_name && <p className="text-xs text-danger font-medium">{errors.last_name.message}</p>}
              </div>
            </div>

            <div className="flex flex-col gap-1.5">
              <label htmlFor="reg-email" className="text-sm font-semibold text-foreground">
                Adresse email <span className="text-danger">*</span>
              </label>
              <input
                id="reg-email"
                type="email"
                autoComplete="email"
                placeholder="votre@email.com"
                className="jdv-input"
                {...register('email', {
                  required: 'Email requis',
                  pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: 'Email invalide' },
                })}
              />
              {errors.email && <p className="text-xs text-danger font-medium">{errors.email.message}</p>}
            </div>

            <div className="flex flex-col gap-1.5">
              <label htmlFor="reg-password" className="text-sm font-semibold text-foreground">
                Mot de passe <span className="text-danger">*</span>
              </label>
              <div className="relative">
                <input
                  id="reg-password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="new-password"
                  placeholder="Minimum 8 caractères"
                  className="jdv-input pr-12"
                  {...register('password', {
                    required: 'Mot de passe requis',
                    minLength: { value: 8, message: 'Minimum 8 caractères' },
                    pattern: { value: /^(?=.*[A-Z])(?=.*[0-9]).{8,}$/, message: 'Doit contenir une majuscule et un chiffre' },
                  })}
                />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors p-1">
                  {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
                </button>
              </div>
              {password && (
                <div className="flex items-center gap-2 mt-1">
                  <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                    <div className={`h-full rounded-full transition-all duration-300 ${strength.color}`} style={{ width: `${(strength.score / 5) * 100}%` }} />
                  </div>
                  <span className="text-xs text-muted-foreground font-medium">{strength.label}</span>
                </div>
              )}
              {errors.password && <p className="text-xs text-danger font-medium">{errors.password.message}</p>}
            </div>

            <div className="flex flex-col gap-1.5">
              <label htmlFor="confirm_password" className="text-sm font-semibold text-foreground">
                Confirmer le mot de passe <span className="text-danger">*</span>
              </label>
              <div className="relative">
                <input
                  id="confirm_password"
                  type={showConfirm ? 'text' : 'password'}
                  autoComplete="new-password"
                  placeholder="Confirmer votre mot de passe"
                  className="jdv-input pr-12"
                  {...register('confirm_password', {
                    required: 'Confirmation requise',
                    validate: (v) => v === password || 'Les mots de passe ne correspondent pas',
                  })}
                />
                <button type="button" onClick={() => setShowConfirm(!showConfirm)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors p-1">
                  {showConfirm ? <EyeOff size={17} /> : <Eye size={17} />}
                </button>
              </div>
              {errors.confirm_password && <p className="text-xs text-danger font-medium">{errors.confirm_password.message}</p>}
            </div>

            <div className="flex flex-col gap-2 pt-1">
              <label className="flex items-start gap-3 cursor-pointer">
                <input type="checkbox" className="mt-0.5 w-4 h-4 rounded border-border bg-input accent-accent cursor-pointer flex-shrink-0"
                  {...register('terms', { required: 'Vous devez accepter les conditions' })} />
                <span className="text-sm text-muted-foreground">
                  J'accepte les{' '}
                  <Link href="/terms" className="text-accent hover:text-accent-light font-medium">conditions d'utilisation</Link>
                  {' '}de JDV GLOBAL CENTER <span className="text-danger">*</span>
                </span>
              </label>
              {errors.terms && <p className="text-xs text-danger font-medium ml-7">{errors.terms.message}</p>}

              <label className="flex items-start gap-3 cursor-pointer">
                <input type="checkbox" className="mt-0.5 w-4 h-4 rounded border-border bg-input accent-accent cursor-pointer flex-shrink-0"
                  {...register('privacy', { required: 'Vous devez accepter la politique de confidentialité' })} />
                <span className="text-sm text-muted-foreground">
                  J'accepte la{' '}
                  <Link href="/privacy" className="text-accent hover:text-accent-light font-medium">politique de confidentialité</Link>
                  {' '}<span className="text-danger">*</span>
                </span>
              </label>
              {errors.privacy && <p className="text-xs text-danger font-medium ml-7">{errors.privacy.message}</p>}
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="btn-primary w-full justify-center py-3.5 text-base disabled:opacity-60 disabled:cursor-not-allowed disabled:transform-none mt-2"
            >
              {isLoading ? <Loader2 size={18} className="animate-spin" /> : 'Créer mon compte'}
            </button>
          </form>

          <p className="text-center text-sm text-muted-foreground mt-6">
            Déjà un compte ?{' '}
            <Link href="/auth/login" className="text-accent hover:text-accent-light font-semibold transition-colors">
              Se connecter
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
