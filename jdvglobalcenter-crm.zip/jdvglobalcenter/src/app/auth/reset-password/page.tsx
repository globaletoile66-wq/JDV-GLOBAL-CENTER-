'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { Eye, EyeOff, Loader2, AlertCircle, CheckCircle2 } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import AppLogo from '@/components/ui/AppLogo';

interface ResetFormData {
  password: string;
  confirm_password: string;
}

export default function ResetPasswordPage() {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const router = useRouter();

  const { register, handleSubmit, watch, formState: { errors } } = useForm<ResetFormData>();
  const password = watch('password', '');

  const onSubmit = async (data: ResetFormData) => {
    setIsLoading(true);
    setError(null);
    try {
      const supabase = createClient();
      const { error: err } = await supabase.auth.updateUser({ password: data.password });
      if (err) throw err;
      setSuccess(true);
      setTimeout(() => router.push('/auth/login'), 2000);
    } catch (err: any) {
      setError(err?.message || 'Une erreur est survenue. Le lien a peut-être expiré.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-6 py-12">
      <div className="max-w-md w-full">
        <div className="flex items-center gap-3 mb-10">
          <AppLogo size={36} />
          <div className="flex flex-col leading-none">
            <span className="font-extrabold text-base text-foreground">JDV</span>
            <span className="text-xs text-muted-foreground tracking-widest uppercase">Global Center</span>
          </div>
        </div>

        {success ? (
          <div className="text-center animate-scale-in">
            <div className="w-16 h-16 rounded-full bg-success/15 border border-success/30 flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 size={32} className="text-success" />
            </div>
            <h2 className="text-2xl font-bold text-foreground mb-3">Mot de passe mis à jour !</h2>
            <p className="text-muted-foreground">Redirection vers la connexion...</p>
          </div>
        ) : (
          <>
            <div className="mb-8">
              <h2 className="text-3xl font-extrabold text-foreground mb-2">Nouveau mot de passe</h2>
              <p className="text-muted-foreground">Choisissez un nouveau mot de passe sécurisé pour votre compte JDV.</p>
            </div>

            {error && (
              <div className="flex items-start gap-3 px-4 py-3 rounded-xl bg-danger/10 border border-danger/25 mb-6">
                <AlertCircle size={16} className="text-danger flex-shrink-0 mt-0.5" />
                <p className="text-sm text-danger font-medium">{error}</p>
              </div>
            )}

            <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-5" noValidate>
              <div className="flex flex-col gap-1.5">
                <label htmlFor="new-password" className="text-sm font-semibold text-foreground">
                  Nouveau mot de passe <span className="text-danger">*</span>
                </label>
                <div className="relative">
                  <input
                    id="new-password"
                    type={showPassword ? 'text' : 'password'}
                    autoComplete="new-password"
                    placeholder="Minimum 8 caractères"
                    className="jdv-input pr-12"
                    {...register('password', {
                      required: 'Mot de passe requis',
                      minLength: { value: 8, message: 'Minimum 8 caractères' },
                      pattern: { value: /^(?=.*[A-Z])(?=.*[0-9]).{8,}$/, message: 'Doit contenir une majuscule et un chiffre' },
                    })}
                  />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-1">
                    {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
                  </button>
                </div>
                {errors.password && <p className="text-xs text-danger font-medium">{errors.password.message}</p>}
              </div>

              <div className="flex flex-col gap-1.5">
                <label htmlFor="confirm-new-password" className="text-sm font-semibold text-foreground">
                  Confirmer le mot de passe <span className="text-danger">*</span>
                </label>
                <div className="relative">
                  <input
                    id="confirm-new-password"
                    type={showConfirm ? 'text' : 'password'}
                    autoComplete="new-password"
                    placeholder="Confirmer votre mot de passe"
                    className="jdv-input pr-12"
                    {...register('confirm_password', {
                      required: 'Confirmation requise',
                      validate: (v) => v === password || 'Les mots de passe ne correspondent pas',
                    })}
                  />
                  <button type="button" onClick={() => setShowConfirm(!showConfirm)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-1">
                    {showConfirm ? <EyeOff size={17} /> : <Eye size={17} />}
                  </button>
                </div>
                {errors.confirm_password && <p className="text-xs text-danger font-medium">{errors.confirm_password.message}</p>}
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="btn-primary w-full justify-center py-3.5 text-base disabled:opacity-60 disabled:cursor-not-allowed disabled:transform-none"
              >
                {isLoading ? <Loader2 size={18} className="animate-spin" /> : 'Mettre à jour le mot de passe'}
              </button>
            </form>

            <p className="text-center text-sm text-muted-foreground mt-6">
              <Link href="/auth/login" className="text-accent hover:text-accent-light font-semibold">
                Retour à la connexion
              </Link>
            </p>
          </>
        )}
      </div>
    </div>
  );
}
