'use client';

import React, { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Building2, Save, Loader2, Briefcase, Eye, Phone } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { createClient } from '@/lib/supabase/client';
import { toast } from 'sonner';

interface BusinessProfile {
  id: string;
  name: string;
  trade_name: string | null;
  description: string | null;
  phone: string | null;
  email: string | null;
  website: string | null;
  address: string | null;
  city: string | null;
  region: string | null;
  business_status: string;
  is_public: boolean;
}

export default function BusinessSettingsPage() {
  const [business, setBusiness] = useState<BusinessProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [form, setForm] = useState<Partial<BusinessProfile>>({});

  const { user } = useAuth();
  const router = useRouter();
  const supabase = createClient();

  const loadBusiness = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase.from('business_profiles').select('*').eq('owner_user_id', user.id).maybeSingle();
    if (data) {
      setBusiness(data);
      setForm(data);
    }
    setIsLoading(false);
  }, [user]);

  useEffect(() => {
    if (!user) { router.push('/auth/login'); return; }
    loadBusiness();
  }, [user, loadBusiness]);

  const handleSave = async () => {
    if (!business) return;
    setIsSaving(true);
    try {
      const { error } = await supabase.from('business_profiles').update({
        name: form.name,
        trade_name: form.trade_name || null,
        description: form.description || null,
        phone: form.phone || null,
        email: form.email || null,
        website: form.website || null,
        address: form.address || null,
        city: form.city || null,
        region: form.region || null,
        is_public: form.is_public,
        business_status: form.business_status,
      }).eq('id', business.id);
      if (error) throw error;
      toast.success('Paramètres enregistrés');
      await loadBusiness();
    } catch (err: any) {
      toast.error(err.message || 'Erreur lors de la sauvegarde');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return <div className="min-h-screen bg-[#0D1F3C] flex items-center justify-center"><Loader2 className="w-8 h-8 text-[#F97316] animate-spin" /></div>;
  }

  if (!business) {
    return (
      <div className="min-h-screen bg-[#0D1F3C] flex items-center justify-center">
        <div className="text-center">
          <p className="text-white/60 mb-4">Aucune entreprise trouvée</p>
          <Link href="/business/create" className="text-[#F97316] hover:underline text-sm">Créer une entreprise</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0D1F3C]">
      <header className="border-b border-white/10 bg-[#0D1F3C]/95 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-3xl mx-auto px-4 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Link href="/business" className="text-white/60 hover:text-white transition-colors p-2 rounded-lg hover:bg-white/10"><ArrowLeft size={18} /></Link>
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-[#F97316] flex items-center justify-center"><Briefcase size={14} className="text-white" /></div>
              <div>
                <h1 className="text-white font-bold text-base leading-none">Paramètres</h1>
                <p className="text-white/40 text-xs">JDV BUSINESS</p>
              </div>
            </div>
          </div>
          <button onClick={handleSave} disabled={isSaving} className="flex items-center gap-2 bg-[#F97316] hover:bg-[#F97316]/90 disabled:opacity-50 text-white text-sm font-medium px-4 py-2 rounded-xl transition-colors">
            {isSaving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
            {isSaving ? 'Enregistrement...' : 'Enregistrer'}
          </button>
        </div>
      </header>

      <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
        {/* General info */}
        <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
          <h2 className="text-white font-semibold mb-4 flex items-center gap-2">
            <Building2 size={16} className="text-[#F97316]" /> Informations générales
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-white/60 text-xs mb-1.5">Nom de l'entreprise *</label>
              <input type="text" value={form.name || ''} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} className="w-full bg-white/10 border border-white/20 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none focus:border-[#F97316]" />
            </div>
            <div>
              <label className="block text-white/60 text-xs mb-1.5">Nom commercial</label>
              <input type="text" value={form.trade_name || ''} onChange={e => setForm(p => ({ ...p, trade_name: e.target.value }))} className="w-full bg-white/10 border border-white/20 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none focus:border-[#F97316]" />
            </div>
          </div>
          <div className="mt-4">
            <label className="block text-white/60 text-xs mb-1.5">Description</label>
            <textarea value={form.description || ''} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} rows={3} className="w-full bg-white/10 border border-white/20 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none focus:border-[#F97316] resize-none" />
          </div>
        </div>

        {/* Contact */}
        <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
          <h2 className="text-white font-semibold mb-4 flex items-center gap-2">
            <Phone size={16} className="text-[#F97316]" /> Coordonnées
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {[
              { label: 'Téléphone', field: 'phone' as const, placeholder: '+229 XX XX XX XX' },
              { label: 'Email', field: 'email' as const, placeholder: 'contact@entreprise.com' },
              { label: 'Site web', field: 'website' as const, placeholder: 'https://...' },
              { label: 'Adresse', field: 'address' as const, placeholder: 'Rue, quartier...' },
              { label: 'Ville', field: 'city' as const, placeholder: 'Cotonou' },
              { label: 'Région', field: 'region' as const, placeholder: 'Littoral' },
            ].map(({ label, field, placeholder }) => (
              <div key={field}>
                <label className="block text-white/60 text-xs mb-1.5">{label}</label>
                <input type="text" value={(form[field] as string) || ''} onChange={e => setForm(p => ({ ...p, [field]: e.target.value }))} placeholder={placeholder} className="w-full bg-white/10 border border-white/20 rounded-xl px-3 py-2.5 text-white placeholder-white/30 text-sm focus:outline-none focus:border-[#F97316]" />
              </div>
            ))}
          </div>
        </div>

        {/* Visibility */}
        <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
          <h2 className="text-white font-semibold mb-4 flex items-center gap-2">
            <Eye size={16} className="text-[#F97316]" /> Visibilité & Statut
          </h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 rounded-xl bg-white/5">
              <div>
                <p className="text-white text-sm font-medium">Profil public</p>
                <p className="text-white/40 text-xs">Rendre votre entreprise visible sur JDV</p>
              </div>
              <button
                onClick={() => setForm(p => ({ ...p, is_public: !p.is_public }))}
                className={`w-12 h-6 rounded-full transition-colors relative ${form.is_public ? 'bg-[#F97316]' : 'bg-white/20'}`}
              >
                <span className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${form.is_public ? 'translate-x-7' : 'translate-x-1'}`} />
              </button>
            </div>
            <div>
              <label className="block text-white/60 text-xs mb-1.5">Statut de l'entreprise</label>
              <select value={form.business_status || 'active'} onChange={e => setForm(p => ({ ...p, business_status: e.target.value }))} className="w-full bg-white/10 border border-white/20 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none focus:border-[#F97316]">
                <option value="draft">Brouillon</option>
                <option value="active">Active</option>
                <option value="suspended">Suspendue</option>
                <option value="archived">Archivée</option>
              </select>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
