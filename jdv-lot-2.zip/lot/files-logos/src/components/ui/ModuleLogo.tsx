import Image from 'next/image';
import type { ReactNode } from 'react';
import { getModuleLogo } from '@/lib/jdv/module-logos';

type Props = { id: string | null | undefined; size?: number; className?: string; alt?: string; fallback?: ReactNode };

/** Logo d'une application JDV ; affiche `fallback` (icône d'origine) si aucun logo n'existe pour cette application. */
export default function ModuleLogo({ id, size = 44, className = '', alt = '', fallback = null }: Props) {
  const src = getModuleLogo(id);
  if (!src) return <>{fallback}</>;
  return (
    <Image
      src={src}
      alt={alt}
      width={size}
      height={size}
      unoptimized
      className={`shrink-0 rounded-xl object-contain ${className}`}
      style={{ width: size, height: size }}
    />
  );
}
