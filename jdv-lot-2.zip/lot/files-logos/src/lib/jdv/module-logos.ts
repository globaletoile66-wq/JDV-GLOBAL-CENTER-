// Logos des applications JDV (fichiers dans /public/assets). Clé = identifiant du registre (application-registry.ts)
// ou code de branche sans le préfixe « jdv_ ». Une application sans logo garde son icône actuelle.
const BRANCHES = '/assets/branches';
const APPS = '/assets/apps';

export const MODULE_LOGOS: Record<string, string> = {
  insurance: `${BRANCHES}/jdv-global-assurance.png`,
  legal: `${BRANCHES}/jdv-legal.png`,
  admin: `${BRANCHES}/jdv-admin.png`,
  crm: `${BRANCHES}/jdv-gestion-clientele.png`,
  tontine: `${BRANCHES}/jdv-tontine.png`,
  entertainment: `${BRANCHES}/jdv-global-divertissement.png`,
  travel: `${BRANCHES}/jdv-voyage.png`,
  immo: `${BRANCHES}/jdv-immo.png`,
  pay: `${BRANCHES}/jdv-pay.png`,
  business: `${APPS}/jdv-business.png`,
  academy: `${APPS}/jdv-education.png`,
  marketplace: `${APPS}/jdv-marketplace.png`,
  pub: `${APPS}/jdv-pub.png`,
  health: `${APPS}/jdv-sante.png`,
  ai: `${APPS}/jdv-global-ia.png`,
  transit: `${APPS}/jdv-logistique.png`,
  agriculture: `${APPS}/jdv-agriculture.png`,
};

// Logo « Tourisme » fourni mais sans application dédiée dans le registre : conservé pour un futur profil.
export const SPARE_LOGOS: Record<string, string> = { tourisme: `${APPS}/jdv-tourisme.png` };

export function getModuleLogo(idOrCode: string | null | undefined): string | null {
  if (!idOrCode) return null;
  const id = idOrCode.replace(/^jdv_/, '');
  return MODULE_LOGOS[id] ?? null;
}
