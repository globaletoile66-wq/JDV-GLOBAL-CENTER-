#!/usr/bin/env bash
# Lot 3 : logos des applications (fichiers, composant, affichage sur la page d'un univers et sur le tableau de bord).
set -uo pipefail
LOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "== Fichiers (logos, mapping, composant)"
cp -r "$LOT/files-logos/." .
echo "logos ajoutés : $(ls public/assets/branches/*.png public/assets/apps/*.png 2>/dev/null | wc -l) fichiers"

echo "== Page d'un univers : logo de chaque application"
python3 - <<'PY'
p='src/app/univers/[slug]/page.tsx'
try: s=open(p,encoding='utf-8').read()
except FileNotFoundError: print('! page univers introuvable, non modifiée'); raise SystemExit(0)
if 'ModuleLogo' in s: print('déjà à jour'); raise SystemExit(0)
imp_anchor="import GlobalHeader from '@/components/navigation/GlobalHeader';"
old='<span className="flex h-11 w-11 items-center justify-center rounded-xl bg-accent/10 text-accent"><Icon size={21} /></span>'
if imp_anchor not in s or old not in s: print('! repères introuvables, page univers non modifiée'); raise SystemExit(0)
new='<ModuleLogo id={id} size={56} alt="" fallback={'+old+'} />'
s=s.replace(imp_anchor, imp_anchor+"\nimport ModuleLogo from '@/components/ui/ModuleLogo';",1).replace(old,new,1)
open(p,'w',encoding='utf-8').write(s); print('page univers : logo affiché sur chaque carte d’application')
PY

echo "== Tableau de bord : logo de chaque branche"
python3 - <<'PY'
p='src/components/dashboard/BranchesGrid.tsx'
try: s=open(p,encoding='utf-8').read()
except FileNotFoundError: print('tableau de bord absent : étape ignorée'); raise SystemExit(0)
if 'ModuleLogo' in s: print('déjà à jour'); raise SystemExit(0)
imp="import { createClient } from '@/lib/supabase/client';"
old='<span className="text-2xl" aria-hidden>{b.icon}</span>'
if imp not in s or old not in s: print('! repères introuvables, tableau de bord non modifié'); raise SystemExit(0)
new='<ModuleLogo id={b.code} size={44} fallback={'+old+'} />'
s=s.replace(imp, imp+"\nimport ModuleLogo from '@/components/ui/ModuleLogo';",1).replace(old,new,1)
open(p,'w',encoding='utf-8').write(s); print('tableau de bord : logo affiché sur chaque branche')
PY
echo "fait"
