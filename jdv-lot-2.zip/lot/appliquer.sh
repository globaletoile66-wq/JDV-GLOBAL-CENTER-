#!/usr/bin/env bash
# Lot 2 : traduction étendue (5 langues), sélecteur de langue, assistant d'accueil branché sur /api/ai/chat. Lancé à la racine du dépôt.
set -uo pipefail
LOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MERGE="_fusion-a-fusionner"
blob() { git hash-object "$1" 2>/dev/null || echo "absent"; }

# Copie d'un fichier "de remplacement" seulement si le fichier du dépôt est bien celui sur lequel j'ai travaillé (empreinte git).
# Sinon : rien n'est écrasé, la version du lot est déposée à part pour une fusion à la main.
safe_replace() { # $1=chemin $2=empreinte attendue
  local rel="$1" expected="$2" cur; cur="$(blob "$rel")"
  if [ ! -e "$rel" ] || [ "$cur" = "$expected" ]; then mkdir -p "$(dirname "$rel")"; cp "$LOT/files/$rel" "$rel"; echo "remplacé : $rel"
  else mkdir -p "$(dirname "$MERGE/$rel")"; cp "$LOT/files/$rel" "$MERGE/$rel"; echo "! $rel a changé depuis ma lecture : version du lot déposée dans $MERGE/$rel"; fi
}

echo "== Nouveaux fichiers"
for f in src/lib/i18n-extra.ts src/hooks/useT.ts src/components/ui/LanguageSwitcher.tsx; do mkdir -p "$(dirname "$f")"; cp "$LOT/files/$f" "$f"; echo "ajouté : $f"; done

echo "== Fichiers remplacés (avec contrôle d'empreinte)"
safe_replace src/app/page.tsx ce1256606c4bfd3899b88e2da3579dd2bddf9924
if [ -f src/components/home/AssistantWidget.tsx ]; then cp "$LOT/files/src/components/home/AssistantWidget.tsx" src/components/home/AssistantWidget.tsx; echo "remplacé : AssistantWidget (branché sur /api/ai/chat)"; else mkdir -p src/components/home; cp "$LOT/files/src/components/home/AssistantWidget.tsx" src/components/home/AssistantWidget.tsx; echo "ajouté : AssistantWidget"; fi

echo "== Moteur de traduction (i18n.ts)"
python3 - <<'PY'
p='src/lib/i18n.ts'
try: s=open(p,encoding='utf-8').read()
except FileNotFoundError: print('! src/lib/i18n.ts introuvable'); raise SystemExit(0)
if 'extraMessages' in s: print('i18n.ts déjà à jour'); raise SystemExit(0)
head="export type JDVLanguage = 'fr' | 'en' | 'pt' | 'es' | 'ar';"
tail="export function translate(language: string, key: string): string {"
if head not in s or tail not in s: print('! i18n.ts : repères introuvables, non modifié'); raise SystemExit(0)
s=s.replace(head,"import { extraMessages } from './i18n-extra';\n\n"+head,1)
i=s.index(tail)
s=s[:i]+'''function lookup(language: string, key: string): string | undefined {
  const locale = (language in messages ? language : 'fr') as JDVLanguage;
  return messages[locale][key] ?? extraMessages[locale]?.[key] ?? messages.fr[key] ?? extraMessages.fr[key];
}

function interpolate(text: string, vars?: Record<string, string | number>): string {
  if (!vars) return text;
  return text.replace(/\\{(\\w+)\\}/g, (match, name: string) => (name in vars ? String(vars[name]) : match));
}

export function translate(language: string, key: string, vars?: Record<string, string | number>): string {
  return interpolate(lookup(language, key) ?? key, vars);
}

/** Comme translate, mais renvoie le texte de repli (au lieu de la clé) si la clé n’existe dans aucune langue. */
export function translateOr(language: string, key: string, fallback: string, vars?: Record<string, string | number>): string {
  return interpolate(lookup(language, key) ?? fallback, vars);
}
'''
open(p,'w',encoding='utf-8').write(s); print('i18n.ts : interpolation, dictionnaire étendu et translateOr ajoutés')
PY

echo "== Détection de la langue du navigateur (JDVContext)"
python3 - <<'PY'
p='src/contexts/JDVContext.tsx'
try: s=open(p,encoding='utf-8').read()
except FileNotFoundError: print('! JDVContext.tsx introuvable'); raise SystemExit(0)
old="      if (stored && ['fr', 'en', 'pt', 'es', 'ar'].includes(stored)) setActiveLanguageState(stored);"
new="""      const supported = ['fr', 'en', 'pt', 'es', 'ar'];
      if (stored && supported.includes(stored)) setActiveLanguageState(stored);
      else {
        const browser = (window.navigator.language || 'fr').slice(0, 2).toLowerCase();
        if (supported.includes(browser)) setActiveLanguageState(browser);
      }"""
if 'const supported' in s: print('JDVContext déjà à jour')
elif old not in s: print('! JDVContext : repère introuvable, non modifié')
else: open(p,'w',encoding='utf-8').write(s.replace(old,new,1)); print('JDVContext : langue du navigateur détectée au premier passage')
PY
echo "== Nettoyage et versionnement"
if [ -d _a-revoir ]; then rm -rf _a-revoir; echo "supprimé : _a-revoir (anciennes copies à plat, déjà archivées dans l'historique git)"; fi
mkdir -p database/migrations
if [ ! -f database/migrations/20261018_jdv_security_hardening_v2.sql ]; then cp "$LOT/files/database/migrations/20261018_jdv_security_hardening_v2.sql" database/migrations/; echo "ajouté : migration de sécurité v2 (déjà appliquée en production)"; fi
echo "fait"
