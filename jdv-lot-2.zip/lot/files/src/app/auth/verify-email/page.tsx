'use client';
import { Suspense, useEffect, useState } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { useT } from '@/hooks/useT';

function VerifyEmail() {
  const email = useSearchParams()?.get('email') ?? '';
  const { t } = useT();
  const [cooldown, setCooldown] = useState(0);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => { if (cooldown <= 0) return; const timer = setTimeout(() => setCooldown(cooldown - 1), 1000); return () => clearTimeout(timer); }, [cooldown]);

  async function resend() {
    if (!email || cooldown > 0) return;
    setBusy(true); setMsg(null);
    const { error } = await createClient().auth.resend({
      type: 'signup', email,
      options: { emailRedirectTo: `${window.location.origin}/auth/callback?next=/onboarding` },
    });
    setBusy(false);
    if (error) setMsg({ ok: false, text: /rate|seconds|too many/i.test(error.message) ? t('auth.verify.rateLimited') : t('auth.verify.resendFailed') });
    else { setMsg({ ok: true, text: t('auth.verify.resent') }); setCooldown(60); }
  }

  return (
    <main className="jdv-home flex min-h-screen items-center justify-center px-5">
      <div className="w-full max-w-md rounded-2xl border border-[var(--jdv-border)] bg-white p-8 text-center">
        <div className="text-5xl" aria-hidden>✉️</div>
        <h1 className="mt-3 text-2xl font-bold" style={{ color: 'var(--jdv-primary-text)' }}>{t('auth.verify.title')}</h1>
        <p className="mt-3 text-sm text-[var(--jdv-muted)]">
          {email ? <>{t('auth.verify.sentToPre')}<strong>{email}</strong>{t('auth.verify.sentToPost')}</> : t('auth.verify.sentGeneric')} {t('auth.verify.next')}
        </p>
        {email && (
          <button type="button" onClick={resend} disabled={busy || cooldown > 0} className="mt-6 w-full rounded-lg px-4 py-2 font-medium disabled:opacity-60" style={{ background: 'var(--jdv-primary)', color: 'var(--jdv-on-primary)' }}>
            {cooldown > 0 ? t('auth.verify.resendCooldown', { s: cooldown }) : busy ? t('auth.verify.sending') : t('auth.verify.resend')}
          </button>
        )}
        {msg && <p role="status" className={`mt-3 text-sm ${msg.ok ? 'text-green-700' : 'text-red-700'}`}>{msg.text}</p>}
        <p className="mt-6 text-sm"><Link href="/auth/login" className="underline" style={{ color: 'var(--jdv-primary-text)' }}>{t('auth.backToLogin')}</Link></p>
      </div>
    </main>
  );
}
export default function Page() { return <Suspense><VerifyEmail /></Suspense>; }
