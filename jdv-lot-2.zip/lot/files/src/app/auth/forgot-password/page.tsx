'use client';
import { FormEvent, useState } from 'react';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/client';
import AppLogo from '@/components/ui/AppLogo';
import LanguageSwitcher from '@/components/ui/LanguageSwitcher';
import { useT } from '@/hooks/useT';
import { Loader2 } from 'lucide-react';

export default function ForgotPasswordPage() {
  const supabase = createClient();
  const { t } = useT();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const result = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: typeof window !== 'undefined' ? window.location.origin + '/auth/callback?next=/auth/reset-password' : undefined,
    });
    if (result.error) setError(result.error.message); else setSent(true);
    setLoading(false);
  }

  return <main className="min-h-screen bg-background flex items-center justify-center px-4"><section className="w-full max-w-md rounded-2xl border border-border bg-card p-6 shadow-xl">
    <div className="flex items-center justify-between gap-3 mb-8"><div className="flex items-center gap-3"><AppLogo size={44}/><div><h1 className="font-extrabold">{t('auth.forgot.title')}</h1><p className="text-xs text-muted-foreground">JDV GLOBAL CENTER</p></div></div><LanguageSwitcher /></div>
    {sent ? <div className="space-y-5"><p className="text-sm text-muted-foreground">{t('auth.forgot.sent')}</p><Link href="/auth/login" className="btn-primary w-full justify-center">{t('auth.backToLogin')}</Link></div> :
    <form onSubmit={submit} className="space-y-5"><input type="email" required placeholder={t('auth.emailPlaceholder')} aria-label={t('auth.email')} value={email} onChange={e => setEmail(e.target.value)} className="jdv-input w-full"/>{error && <p className="text-sm text-danger">{error}</p>}<button disabled={loading} className="btn-primary w-full justify-center">{loading ? <Loader2 className="animate-spin" size={18}/> : t('auth.forgot.send')}</button><Link href="/auth/login" className="block text-center text-sm text-accent">{t('auth.forgot.back')}</Link></form>}
  </section></main>;
}
