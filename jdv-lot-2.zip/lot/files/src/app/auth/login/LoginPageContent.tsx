'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { Eye, EyeOff, Loader2, AlertCircle, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import AppLogo from '@/components/ui/AppLogo';
import LanguageSwitcher from '@/components/ui/LanguageSwitcher';
import { createClient } from '@/lib/supabase/client';
import { needsMfaChallenge, safeRedirect } from '@/lib/auth/mfa';
import { useT } from '@/hooks/useT';

interface LoginFormData {
  email: string;
  password: string;
}

export default function LoginPageContent() {
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const { signIn } = useAuth();
  const { t } = useT();
  const router = useRouter();
  const searchParams = useSearchParams();
  const requestedRedirect = searchParams?.get('redirect');
  const redirectTo = requestedRedirect &&
    requestedRedirect.startsWith('/') &&
    !requestedRedirect.startsWith('//') &&
    !requestedRedirect.includes('\\')
      ? requestedRedirect
      : '/dashboard';

  const { register, handleSubmit, formState: { errors } } = useForm<LoginFormData>();

  const onSubmit = async (data: LoginFormData) => {
    setIsLoading(true);
    setAuthError(null);
    try {
      await signIn(data.email, data.password);

      // Conceivers must land in the full platform control center, not the
      // generic dashboard that routes ordinary users to a single workspace.
      const { data: superAdmin } = await createClient().rpc('is_super_admin');
      const destination = superAdmin === true
        ? '/hidden-concepteur-gate/dashboard'
        : redirectTo;

      toast.success(t('auth.login.success'));
      if (await needsMfaChallenge(createClient())) {
        router.replace(`/auth/mfa?redirect=${encodeURIComponent(destination)}`);
        return;
      }
      router.replace(safeRedirect(destination));
      router.refresh();
    } catch (err: any) {
      const msg = err?.message || t('auth.err.generic');
      if (msg.includes('Invalid login credentials')) {
        setAuthError(t('auth.err.invalid'));
      } else if (msg.includes('Email not confirmed')) {
        setAuthError(t('auth.err.unconfirmed'));
      } else if (msg.includes('Too many requests')) {
        setAuthError(t('auth.err.tooMany'));
      } else {
        setAuthError(msg);
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex">
      {/* Brand panel */}
      <div className="hidden lg:flex lg:w-1/2 bg-jdv-gradient relative overflow-hidden flex-col justify-between p-12">
        <div className="absolute inset-0 bg-jdv-hero" />
        <div className="absolute top-1/3 left-1/4 w-96 h-96 blob-primary opacity-60" />
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 blob-accent opacity-40" />
        <div className="relative z-10">
          <Link href="/" className="flex items-center gap-3 group">
            <AppLogo size={44} />
            <div className="flex flex-col leading-none">
              <span className="font-extrabold text-xl tracking-tight text-white">JDV</span>
              <span className="text-xs font-medium text-white/60 tracking-widest uppercase">Global Center</span>
            </div>
          </Link>
        </div>
        <div className="relative z-10">
          <h1 className="text-4xl font-extrabold text-white mb-4 leading-tight">
            {t('auth.login.heroA')}<br />
            <span className="text-accent">{t('auth.login.heroB')}</span> {t('auth.login.heroC')}
          </h1>
          <p className="text-white/70 text-lg leading-relaxed">
            {t('auth.login.heroText')}
          </p>
        </div>
        <div className="relative z-10 flex items-center gap-4">
          <div className="flex -space-x-2">
            {['🇧🇯', '🇸🇳', '🇨🇮', '🇳🇬', '🇫🇷'].map((flag, i) => (
              <div key={i} className="w-8 h-8 rounded-full bg-card border-2 border-border flex items-center justify-center text-sm">{flag}</div>
            ))}
          </div>
          <p className="text-white/60 text-sm">{t('auth.login.countries')}</p>
        </div>
      </div>

      {/* Form panel */}
      <div className="flex-1 flex flex-col justify-center px-6 py-12 lg:px-16 xl:px-24">
        <div className="max-w-md w-full mx-auto">
          <div className="lg:hidden flex items-center gap-3 mb-8">
            <AppLogo size={36} />
            <div className="flex flex-col leading-none">
              <span className="font-extrabold text-base text-foreground">JDV</span>
              <span className="text-xs text-muted-foreground tracking-widest uppercase">Global Center</span>
            </div>
          </div>

          <div className="mb-8 flex items-center justify-between gap-3">
            <Link href="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
              <ArrowLeft size={15} className="rtl:rotate-180" />
              {t('auth.login.back')}
            </Link>
            <LanguageSwitcher />
          </div>

          <div className="mb-8">
            <h2 className="text-3xl font-extrabold text-foreground mb-2">{t('auth.login.welcomeBack')}</h2>
            <p className="text-muted-foreground">{t('auth.login.subtitle')}</p>
          </div>

          {authError && (
            <div className="flex items-start gap-3 px-4 py-3 rounded-xl bg-danger/10 border border-danger/25 mb-6 animate-slide-up">
              <AlertCircle size={16} className="text-danger flex-shrink-0 mt-0.5" />
              <p className="text-sm text-danger font-medium leading-snug">{authError}</p>
            </div>
          )}

          <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-5" noValidate>
            <div className="flex flex-col gap-1.5">
              <label htmlFor="email" className="text-sm font-semibold text-foreground">
                {t('auth.email')} <span className="text-danger">*</span>
              </label>
              <input
                id="email"
                type="email"
                autoComplete="email"
                placeholder={t('auth.emailPlaceholder')}
                className="jdv-input"
                {...register('email', {
                  required: t('auth.emailRequired'),
                  pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: t('auth.emailInvalid') },
                })}
              />
              {errors.email && <p className="text-xs text-danger font-medium">{errors.email.message}</p>}
            </div>

            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between">
                <label htmlFor="password" className="text-sm font-semibold text-foreground">
                  {t('auth.password')} <span className="text-danger">*</span>
                </label>
                <Link href="/auth/forgot-password" className="text-xs text-accent hover:text-accent-light transition-colors font-medium">
                  {t('auth.forgot')}
                </Link>
              </div>
              <div className="relative">
                <input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  placeholder={t('auth.passwordPlaceholder')}
                  className="jdv-input pe-12"
                  {...register('password', { required: t('auth.passwordRequired') })}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute end-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors p-1"
                  aria-label={showPassword ? t('auth.hide') : t('auth.show')}
                >
                  {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
                </button>
              </div>
              {errors.password && <p className="text-xs text-danger font-medium">{errors.password.message}</p>}
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="btn-primary w-full justify-center py-3.5 text-base disabled:opacity-60 disabled:cursor-not-allowed disabled:transform-none mt-2"
            >
              {isLoading ? <Loader2 size={18} className="animate-spin" /> : t('auth.signIn')}
            </button>
          </form>

          <p className="text-center text-sm text-muted-foreground mt-8">
            {t('auth.noAccount')}{' '}
            <Link href="/auth/register" className="text-accent hover:text-accent-light font-semibold transition-colors">
              {t('auth.createAccount')}
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
